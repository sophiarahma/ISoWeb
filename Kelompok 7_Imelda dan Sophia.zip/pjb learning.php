<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="cssisi.css">
    <title>PjBL</title>
</head>
<body>
    <header>
		<input type="image" src="iso fix.png"/>
        <h1>Apa itu PjBL (Project Based Learning?)</h1>
        <nav>
            <ul>
                <li><a href="#Pengertian">Pengertian</a></li>
                <li><a href="#Karakteristik">Karakteristik</a></li>
                <li><a href="#Langkah-langkah">Langkah-langkah</a></li>
                <li><a href="#Kelebihan">Kelebihan</a></li>
                <li><a href="#Kekurangan">Kekurangan</a></li>
				<li><a href="coba.php">Home</a></li>
            </ul>
        </nav>
    </header>
	
<!--Pengertian-->
    <section id="Pengertian" >
        <h2>A. Pengertian</h2>
        <p>Fathurrohman (2016: 119) berpendapat bahwa pembelajaran berbasis proyek merupakan model pembelajaran yang menggunakan proyek/kegiatan sebagai sarana pembelajaran untuk mencapai kompetensi sikap, pengetahuan dan keterampilan.</p>
		<p>Surya, dkk (2018:45) menyatakan bahwa model pembelajaran Project Based Learning (PjBL) merupakan pembelajaran yang inovatif yang berpusat kepada siswa (Student Centered) dan menempatkan guru sebagai motivator dan fasilitator, dimana dalam hal ini, guru memberi peluang kepada siswa untuk bekerja secara otonom mengkonstruksi belajarnya.</p>
		<p>Mayuni, dkk (2019) menyatakan bahwa project based learning (PjBL) merupakan model, strategi, atau metode pembelajaran yang berpusat pada siswa, dimana siswa diajak untuk mengembangkan sendiri kemampuan yang ada dalam diri mereka dengan menciptakan proyek belajar (kegiatan), sehingga diharapkan dapat mengembangkan kemampuan kreatifitas dan berfikir kritis mereka</p>
		<p>Berdasarkan pernyataan para ahli tersebut, Project-Based Learning atau pembelajaran berbasis proyek adalah pembelajaran yang inovatif yang melibatkan siswa untuk mengerjakan sebuah proyek secara otonom, sehingga dapat mengembangkan kemampuan kreatifitas dan berfikir kritis mereka.</p>
    </section>
	
	<!--Karakteristik-->
    <section id="Karakteristik">
        <h2>B. Karakteristik</h2>
        <p>-	Guru sebagai fasilitator serta mengevaluasi produk hasil kerja</p>
		<p>-	Menggunakan proyek sebagai media pembelajaran</p>
		<p>-	Menggunakan masalah yang ada pada kehidupan sehari-hari siswa sebagai langkah awal pembelajaran</p>
		<p>-	Menekankan pembelajaran kontekstual</p>
		<p>-	Menciptakan suatu produk sederhana sebagai hasil pembelajaran proyek.</p>
    </section>
	
	<!--Langkah-langkah-->
    <section id="Langkah-langkah">
        <h2>C. Langkah-langkah</h2>
        <p>-	Guru sebagai fasilitator serta mengevaluasi produk hasil kerja</p>
		<p>-	Menggunakan proyek sebagai media pembelajaran</p>
		<p>-	Menggunakan masalah yang ada pada kehidupan sehari-hari siswa sebagai langkah awal pembelajaran</p>
		<p>-	Menekankan pembelajaran kontekstual</p>
		<p>-	Menciptakan suatu produk sederhana sebagai hasil pembelajaran proyek.</p>
    </section>
	
	<!--Kelebihan-->
    <section id="Kelebihan">
        <h2>D. Kelebihan</h2>
        <p>-	Guru sebagai fasilitator serta mengevaluasi produk hasil kerja</p>
		<p>-	Menggunakan proyek sebagai media pembelajaran</p>
		<p>-	Menggunakan masalah yang ada pada kehidupan sehari-hari siswa sebagai langkah awal pembelajaran</p>
		<p>-	Menekankan pembelajaran kontekstual</p>
		<p>-	Menciptakan suatu produk sederhana sebagai hasil pembelajaran proyek.</p>
    </section>
	
	<!--Kekurangan-->
    <section id="Kekurangan">
        <h2>E. Kekurangan</h2>
        <p>-	Guru sebagai fasilitator serta mengevaluasi produk hasil kerja</p>
		<p>-	Menggunakan proyek sebagai media pembelajaran</p>
		<p>-	Menggunakan masalah yang ada pada kehidupan sehari-hari siswa sebagai langkah awal pembelajaran</p>
		<p>-	Menekankan pembelajaran kontekstual</p>
		<p>-	Menciptakan suatu produk sederhana sebagai hasil pembelajaran proyek.</p>
    </section>

    <footer>
        <p>&copy; 2023. <b>Iso.web</b> All Rights Reserved.</p>
    </footer>
</body>
</html>