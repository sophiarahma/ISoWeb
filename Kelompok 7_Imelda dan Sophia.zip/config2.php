<?php

$conn = mysqli_connect('localhost','root','','projek_desain_web2');

?>